package me.Danker.features.loot;

import me.Danker.commands.ToggleCommand;
import me.Danker.handlers.ConfigHandler;
import me.Danker.utils.Utils;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StringUtils;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class EndermanTracker {

    public static int voidglooms;
    public static int nullSpheres;
    public static int TAP;
    public static int TAPDrops;
    public static int endersnakes;
    public static int summoningEyes;
    public static int manaBooks;
    public static int tuners;
    public static int atoms;
    public static int hazmats;
    public static int espressoMachines;
    public static int smartyBooks;
    public static int endRunes;
    public static int chalices;
    public static int dice;
    public static int artifacts;
    public static int skins;
    public static int mergers;
    public static int cores;
    public static int enchantRunes;
    public static int enderBooks;
    public static double time;
    public static int bosses;

    public static int voidgloomsSession = 0;
    public static int nullSpheresSession = 0;
    public static int TAPSession = 0;
    public static int TAPDropsSession = 0;
    public static int endersnakesSession = 0;
    public static int summoningEyesSession = 0;
    public static int manaBooksSession = 0;
    public static int tunersSession = 0;
    public static int atomsSession = 0;
    public static int hazmatsSession = 0;
    public static int espressoMachinesSession = 0;
    public static int smartyBooksSession = 0;
    public static int endRunesSession = 0;
    public static int chalicesSession = 0;
    public static int diceSession = 0;
    public static int artifactsSession = 0;
    public static int skinsSession = 0;
    public static int mergersSession = 0;
    public static int coresSession = 0;
    public static int enchantRunesSession = 0;
    public static int enderBooksSession = 0;
    public static double timeSession = -1;
    public static int bossesSession = -1;

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        String message = StringUtils.stripControlCodes(event.message.getUnformattedText());

        if (!Utils.inSkyblock) return;
        if (event.type == 2) return;
        if (message.contains(":")) return;

        boolean rng = false;

        if (message.contains("   Enderman Slayer LVL ")) {
            voidglooms++;
            voidgloomsSession++;
            if (bosses != -1) {
                bosses++;
            }
            if (bossesSession != -1) {
                bossesSession++;
            }
            ConfigHandler.writeIntConfig("enderman", "voidglooms", voidglooms);
            ConfigHandler.writeIntConfig("enderman", "bossRNG", bosses);
        } else if (message.contains("RARE DROP! (") && message.contains("Twilight Arrow Poison)")) {
            int amount = LootTracker.getAmountfromMessage(message);
            TAP += amount;
            TAPSession += amount;
            TAPDrops++;
            TAPDropsSession++;
            ConfigHandler.writeIntConfig("enderman", "tap", TAP);
            ConfigHandler.writeIntConfig("enderman", "tapDrops", TAPDrops);
        } else if (message.contains("VERY RARE DROP!  (") && message.contains(" Endersnake Rune I)")) {
            endersnakes++;
            endersnakesSession++;
            ConfigHandler.writeIntConfig("enderman", "endersnakes", endersnakes);
        } else if (message.contains("VERY RARE DROP!  (Summoning Eye)")) {
            summoningEyes++;
            summoningEyesSession++;
            ConfigHandler.writeIntConfig("enderman", "summoningEyes", summoningEyes);
        } else if (message.contains("VERY RARE DROP!  (Mana Steal I)")) {
            manaBooks++;
            manaBooksSession++;
            ConfigHandler.writeIntConfig("enderman", "manaBooks", manaBooks);
        } else if (message.contains("VERY RARE DROP!  (Transmission Tuner)")) {
            tuners++;
            tunersSession++;
            ConfigHandler.writeIntConfig("enderman", "tuners", tuners);
        } else if (message.contains("VERY RARE DROP!  (Null Atom)")) {
            atoms++;
            atomsSession++;
            ConfigHandler.writeIntConfig("enderman", "atoms", atoms);
        } else if (message.contains("VERY RARE DROP!  (Hazmat Enderman)")) {
            hazmats++;
            hazmatsSession++;
            ConfigHandler.writeIntConfig("enderman", "hazmats", hazmats);
        } else if (message.contains("CRAZY RARE DROP!  (Pocket Espresso Machine)")) {
            rng = true;
            espressoMachines++;
            espressoMachinesSession++;
            ConfigHandler.writeIntConfig("enderman", "espressoMachines", espressoMachines);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.AQUA + "POCKET ESPRESSO MACHINE!", 3);
        } else if (message.contains("VERY RARE DROP!  (Smarty Pants I)")) {
            smartyBooks++;
            smartyBooksSession++;
            ConfigHandler.writeIntConfig("enderman", "smartyBooks", smartyBooks);
        } else if (message.contains("VERY RARE DROP!  (") && message.contains(" End Rune I)")) {
            endRunes++;
            endRunesSession++;
            ConfigHandler.writeIntConfig("enderman", "endRunes", endRunes);
        } else if (message.contains("CRAZY RARE DROP!  (Handy Blood Chalice)")) {
            rng = true;
            chalices++;
            chalicesSession++;
            ConfigHandler.writeIntConfig("enderman", "chalices", chalices);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.RED + "HANDY BLOOD CHALICE!", 3);
        } else if (message.contains("VERY RARE DROP!  (Sinful Dice)")) {
            dice++;
            diceSession++;
            ConfigHandler.writeIntConfig("enderman", "dice", dice);
        } else if (message.contains("CRAZY RARE DROP!  (Exceedingly Rare Ender Artifact Upgrader)")) {
            rng = true;
            artifacts++;
            artifactsSession++;
            ConfigHandler.writeIntConfig("enderman", "artifacts", artifacts);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.DARK_PURPLE + "ENDER ARTIFACT UPGRADER!", 3);
        } else if (message.contains("CRAZY RARE DROP!  (Void Conqueror Enderman Skin)")) {
            rng = true;
            skins++;
            skinsSession++;
            ConfigHandler.writeIntConfig("enderman", "skins", skins);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.DARK_PURPLE + "ENDERMAN SKIN!", 3);
        } else if (message.contains("VERY RARE DROP!  (Etherwarp Merger)")) {
            mergers++;
            mergersSession++;
            ConfigHandler.writeIntConfig("enderman", "mergers", mergers);
        } else if (message.contains("CRAZY RARE DROP!  (Judgement Core)")) {
            rng = true;
            cores++;
            coresSession++;
            ConfigHandler.writeIntConfig("enderman", "cores", cores);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.GOLD + "JUDGEMENT CORE!", 5);
        } else if (message.contains("CRAZY RARE DROP!  (") && message.contains(" Enchant Rune I)")) {
            rng = true;
            enchantRunes++;
            enchantRunesSession++;
            ConfigHandler.writeIntConfig("enderman", "enchantRunes", enchantRunes);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.GRAY + "ENCHANT RUNE!", 3);
        } else if (message.contains("INSANE DROP!  (Ender Slayer VII)") || message.contains("CRAZY RARE DROP!  (Ender Slayer VII)")) {
            rng = true;
            enderBooks++;
            enderBooksSession++;
            ConfigHandler.writeIntConfig("enderman", "enderBooks", enderBooks);
            if (ToggleCommand.rngesusAlerts) Utils.createTitle(EnumChatFormatting.RED + "ENDER SLAYER VII!", 3);
        }

        if (rng) {
            time = System.currentTimeMillis() / 1000;
            bosses = 0;
            timeSession = System.currentTimeMillis() / 1000;
            bossesSession = 0;
            ConfigHandler.writeDoubleConfig("enderman", "timeRNG", time);
            ConfigHandler.writeIntConfig("enderman", "bossRNG", 0);
        }
    }

}
